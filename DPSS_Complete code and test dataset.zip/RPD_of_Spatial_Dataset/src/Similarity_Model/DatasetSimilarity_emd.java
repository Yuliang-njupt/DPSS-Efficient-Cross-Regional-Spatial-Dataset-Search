package Similarity_Model;

public class DatasetSimilarity_emd {
    public int index; // 数据集的索引号
    public double[][] dataset; // 归一化后的数据集
    public double emd; // 与样本数据集的EMD值

    public DatasetSimilarity_emd(int index, double[][] dataset, double emd) {
        this.index = index;
        this.dataset = dataset;
        this.emd = emd;
    }
}
