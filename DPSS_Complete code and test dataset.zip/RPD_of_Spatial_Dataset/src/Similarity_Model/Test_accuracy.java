package Similarity_Model;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

import static Similarity_Model.Probability_density_distribution.*;
import static Similarity_Model.Read_Files.readCsvFilesFromDirectory;
import static Similarity_Model.Index.*;

public class Test_accuracy {
    private static final int [] resolutions = {8, 16, 32, 64, 128};//网格划分参数，2的整次幂;256/512/1024/2048
    private static final int [] Top_Ks = {5};
    private static final int [] Sizes = {200, 400, 600, 800, 1000};
    private static final double [] alphas = {0.1, 0.2, 0.3, 0.4, 0.5, 0.6};//带宽控制参数
    private static final double [] lamdas = {0.2, 0.4, 0.6, 0.8, 1.0, 1.2};//过滤参数
    private static final int iterations = 100;

    public static void main(String[] args) {
        int Top_K = 5;
        double lamda = 0.6;
        int resolution = 128;
        double alpha = 0.2;
        int Size = 1000;

        for (int a = 0; a < Sizes.length; a++) {
            Size = Sizes[a];

            // 根据需要测试的参数决定要不要只读一遍（resolution/size/alpha需要放在循环里去多次读取）
            String directoryPath = "F:\\论文数据\\XYConverter public 0-" + Size;
            String pdfFilePath = directoryPath + "_PDFs_3h_" + resolution + "_" + alpha + ".ser"; // 定义保存路径

            List<Map<GridIndex, Double>> PDFs;
            File pdfFile = new File(pdfFilePath);
            if (pdfFile.exists()) {
                // 如果文件存在，加载 PDFs
                PDFs = DataPersistence.loadPDFsFromFile(pdfFilePath);
            } else {
                // 否则执行计算并保存 PDFs
                List<List<Double[]>> dataWarehouse = readCsvFilesFromDirectory(directoryPath);
                List<Map<GridIndex, Integer>> gridCounts = gridCounts(dataWarehouse, resolution);
                PDFs = calculateKDE(gridCounts, resolution, alpha, new GaussianKernel());
                //if (alpha == 0.2) {
                    DataPersistence.savePDFsToFile(PDFs, pdfFilePath);  // 保存 PDFs
                //}
            }

            System.out.println("resolution: " + resolution);
            System.out.println("alpha: " + alpha);
            System.out.println("lamda: " + lamda);
            System.out.println("Top_K: " + Top_K);
            System.out.println("Sizes: " + Size);

            Random random = new Random(42); // 随机数生成器
            double totalAccuracy = 0; // 累计准确性

            //构建索引树
            Map<Integer, double[]> stats = calculateHilbertStats(PDFs, resolution);
            buildIndexTree(stats);

            //进行多次实验取平均结果
            for (int i = 0; i < iterations; i++) {
                // 处理query
                int sampleIdx = random.nextInt(PDFs.size());
                final Map<GridIndex, Double> sample = PDFs.get(sampleIdx);
                double[] sampleStats = stats.get(sampleIdx);
                double targetMean = sampleStats[0];     // 使用 sample 的均值
                double targetVariance = sampleStats[1]; // 使用 sample 的方差

                // 搜索
                //baseline
                List<DatasetSimilarity> baselineResults = findTopKSimilar(PDFs, sample, Top_K);

                // 搜索
                //optimizied
                List<Integer> candidates = filterCandidates(targetMean, targetVariance, lamda);
                List<DatasetSimilarity> optimizedResults = findTopKWithCandidates(sample, PDFs, candidates, Top_K);

                // 处理搜索结果
                // 提取索引号
                List<Integer> baselineIndices = baselineResults.stream().map(ds -> ds.index).collect(Collectors.toList());
                List<Integer> optimizedIndices = optimizedResults.stream().map(ds -> ds.index).collect(Collectors.toList());
                // 计算准确性
                Set<Integer> baselineSet = new HashSet<>(baselineIndices);
                Set<Integer> optimizedSet = new HashSet<>(optimizedIndices);
                baselineSet.retainAll(optimizedSet);
                double accuracy = (double) baselineSet.size() / Math.min(baselineIndices.size(), optimizedIndices.size());
                totalAccuracy += accuracy;
            }

            double averageAccuracy = totalAccuracy / iterations;
            System.out.printf("Average Accuracy: %.2f\n", averageAccuracy * 100);

        }
    }


    public static List<DatasetSimilarity> findTopKWithCandidates(
            Map<GridIndex, Double> sample,
            List<Map<GridIndex, Double>> PDFs,
            List<Integer> candidates,
            int k
    ) {
        // 使用优先队列维护 Top-K 结果
        PriorityQueue<DatasetSimilarity> topK = new PriorityQueue<>(
                Comparator.comparingDouble(ds -> -ds.jsd) // 按 JSD 从大到小排序
        );

        for (int candidateIndex : candidates) {
            Map<GridIndex, Double> candidatePDF = PDFs.get(candidateIndex);

            // 计算 JSD
            double jsd = Similarity_Calculator.calculateJSD(sample, candidatePDF);

            // 构造 DatasetSimilarity 对象
            DatasetSimilarity similarity = new DatasetSimilarity(candidateIndex, candidatePDF, jsd);

            // 动态维护前 K 个最优解
            if (topK.size() < k) {
                topK.add(similarity); // 未达到 K 个时直接加入
            } else if (jsd < topK.peek().jsd) {
                // 如果当前 JSD 小于堆中最大 JSD，则替换最差解
                topK.poll();
                topK.add(similarity);
            }
        }

        // 转换为列表并按 JSD 从小到大排序
        List<DatasetSimilarity> result = new ArrayList<>(topK);
        result.sort(Comparator.comparingDouble(ds -> ds.jsd));
        return result;
    }


    // 查找最相似的前k个数据集并保留索引信息
    public static List<DatasetSimilarity> findTopKSimilar(
            List<Map<GridIndex, Double>> datasets, // 稀疏概率分布
            Map<GridIndex, Double> sample, // 样本分布
            int k) {
        PriorityQueue<DatasetSimilarity> topK = new PriorityQueue<>(
                Comparator.comparingDouble(ds -> -ds.jsd) // 从大到小排序
        );

        for (int i = 0; i < datasets.size(); i++) {
            Map<GridIndex, Double> dataset = datasets.get(i);
            double jsd = Similarity_Calculator.calculateJSD(sample, dataset); // 使用稀疏概率分布计算JSD
            DatasetSimilarity ds = new DatasetSimilarity(i, dataset, jsd);

            if (topK.size() < k) {
                topK.add(ds);
            } else if (jsd < topK.peek().jsd) {
                topK.poll(); // 移除最差相似度的数据集
                topK.add(ds); // 加入新的更相似的数据集
            }
        }

        // 将结果从PriorityQueue转为列表并排序
        List<DatasetSimilarity> result = new ArrayList<>(topK);
        result.sort(Comparator.comparingDouble(ds -> ds.jsd));
        return result;
    }
}
