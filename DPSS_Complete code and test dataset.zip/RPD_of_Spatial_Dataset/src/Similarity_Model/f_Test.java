package Similarity_Model;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

import static Similarity_Model.Probability_density_distribution.*;
import static Similarity_Model.Read_Files.readCsvFiles;
import static Similarity_Model.Read_Files.readCsvFilesFromDirectory;
import static Similarity_Model.Index.*;

public class f_Test {
    private static final int [] resolutions = {32, 64, 128, 256, 512};//网格划分参数，2的整次幂
    private static final int [] Top_Ks = {3, 6, 9, 12, 15};
    private static final double [] bandwidth_ratio = {0.05, 0.10, 0.15, 0.20, 0.25};//KDE的带宽
    private static final double [] ks = {0.1, 0.2, 0.3, 0.4, 0.5, 0.6};//过滤参数
    private static final int iterations = 100;
    private static final int batchSize = 100;

    public static void main(String[] args) {
        for (int a = 0; a < resolutions.length; a++) {
            int resolution = resolutions[a];
            double bandwidth = resolution * bandwidth_ratio[2];

            String directoryPath = "F:\\trackable\\XY trackable13000-14999";
            String pdfFilePath = directoryPath + "_PDFs_" + resolution + "_" + bandwidth + ".ser"; // 定义保存路径

            File directory = new File(directoryPath);
            File[] files = directory.listFiles((dir, name) -> name.endsWith(".csv"));

            if (files != null) {
                // 将文件分批并行处理
                List<Map<GridIndex, Double>> PDFs = Arrays.stream(files)
                        .collect(Collectors.groupingBy(file -> Arrays.asList(files).indexOf(file) / batchSize)) // 按批次分组
                        .values()
                        .parallelStream() // 开启并行流处理每个批次
                        .map(batchFiles -> {
                            try {
                                // 读取当前批次的 CSV 文件
                                List<List<Double[]>> dataWarehouse = readCsvFiles(batchFiles.toArray(new File[0]));

                                // 计算网格计数
                                List<Map<GridIndex, Integer>> gridCounts = gridCounts(dataWarehouse, resolution);

                                // 计算KDE
                                return calculateKDE(gridCounts, resolution, bandwidth, new GaussianKernel());
                            } catch (Exception e) {
                                e.printStackTrace();
                                return Collections.<Map<GridIndex, Double>>emptyList();
                            }
                        })
                        .flatMap(Collection::stream) // 合并每个批次的结果
                        .collect(Collectors.toList());

                // 保存最终的 PDFs
                DataPersistence.savePDFsToFile(PDFs, pdfFilePath);
            }
        }

    }

    public static List<DatasetSimilarity> findTopKWithCandidates(
            Map<GridIndex, Double> sample,
            List<Map<GridIndex, Double>> PDFs,
            List<Integer> candidates,
            int k
    ) {
        // 使用优先队列维护 Top-K 结果
        PriorityQueue<DatasetSimilarity> topK = new PriorityQueue<>(
                Comparator.comparingDouble(ds -> -ds.jsd) // 按 JSD 从大到小排序
        );

        for (int candidateIndex : candidates) {
            Map<GridIndex, Double> candidatePDF = PDFs.get(candidateIndex);

            // 计算 JSD
            double jsd = Similarity_Calculator.calculateJSD(sample, candidatePDF);

            // 构造 DatasetSimilarity 对象
            DatasetSimilarity similarity = new DatasetSimilarity(candidateIndex, candidatePDF, jsd);

            // 动态维护前 K 个最优解
            if (topK.size() < k) {
                topK.add(similarity); // 未达到 K 个时直接加入
            } else if (jsd < topK.peek().jsd) {
                // 如果当前 JSD 小于堆中最大 JSD，则替换最差解
                topK.poll();
                topK.add(similarity);
            }
        }

        // 转换为列表并按 JSD 从小到大排序
        List<DatasetSimilarity> result = new ArrayList<>(topK);
        result.sort(Comparator.comparingDouble(ds -> ds.jsd));
        return result;
    }


    // 查找最相似的前k个数据集并保留索引信息
    public static List<DatasetSimilarity> findTopKSimilar(
            List<Map<GridIndex, Double>> datasets, // 稀疏概率分布
            Map<GridIndex, Double> sample, // 样本分布
            int k) {
        PriorityQueue<DatasetSimilarity> topK = new PriorityQueue<>(
                Comparator.comparingDouble(ds -> -ds.jsd) // 从大到小排序
        );

        for (int i = 0; i < datasets.size(); i++) {
            Map<GridIndex, Double> dataset = datasets.get(i);
            double jsd = Similarity_Calculator.calculateJSD(sample, dataset); // 使用稀疏概率分布计算JSD
            DatasetSimilarity ds = new DatasetSimilarity(i, dataset, jsd);

            if (topK.size() < k) {
                topK.add(ds);
            } else if (jsd < topK.peek().jsd) {
                topK.poll(); // 移除最差相似度的数据集
                topK.add(ds); // 加入新的更相似的数据集
            }
        }

        // 将结果从PriorityQueue转为列表并排序
        List<DatasetSimilarity> result = new ArrayList<>(topK);
        result.sort(Comparator.comparingDouble(ds -> ds.jsd));
        return result;
    }

    private static void PrintMenory() {
        Runtime runtime = Runtime.getRuntime();
        long totalMemory = runtime.totalMemory();
        long freeMemory = runtime.freeMemory();
        long usedMemory = totalMemory - freeMemory;
        double totalMemoryInMB = totalMemory / (1024 * 1024);
        double freeMemoryInMB = freeMemory / (1024 * 1024);
        double usedMemoryInMB = usedMemory / (1024 * 1024);
        System.out.println("Total memory: " + totalMemoryInMB + " MB");
        System.out.println("Used memory: " + usedMemoryInMB + " MB");
        System.out.println("Free memory: " + freeMemoryInMB + " MB");
    }

}
