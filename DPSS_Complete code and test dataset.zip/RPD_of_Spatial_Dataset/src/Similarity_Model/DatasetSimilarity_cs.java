package Similarity_Model;

public class DatasetSimilarity_cs {
    public int index;
    public double[][] dataset;
    public double cosineSimilarity;

    public DatasetSimilarity_cs(int index, double[][] dataset, double cosineSimilarity) {
        this.index = index;
        this.dataset = dataset;
        this.cosineSimilarity = cosineSimilarity;
    }
}

