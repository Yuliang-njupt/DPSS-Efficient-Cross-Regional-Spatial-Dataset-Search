package Similarity_Model;

import java.io.*;
import java.util.List;
import java.util.Map;

public class DataPersistence {

    public static void savePDFsToFile(List<Map<GridIndex, Double>> PDFs, String filePath) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filePath))) {
            out.writeObject(PDFs);  // 将 PDF 对象写入文件
            System.out.println("PDFs 数据已成功保存");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Map<GridIndex, Double>> loadPDFsFromFile(String filePath) {
        List<Map<GridIndex, Double>> PDFs = null;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filePath))) {
            PDFs = (List<Map<GridIndex, Double>>) in.readObject();  // 从文件加载 PDF 数据
            System.out.println("PDFs 数据已成功加载");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return PDFs;
    }
}

