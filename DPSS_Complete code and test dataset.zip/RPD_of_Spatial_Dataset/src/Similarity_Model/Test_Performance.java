package Similarity_Model;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

import static Similarity_Model.Probability_density_distribution.*;
import static Similarity_Model.Read_Files.readCsvFilesFromDirectory;
import static Similarity_Model.Index.*;

public class Test_Performance {

    private static final int [] resolutions = {32, 64, 128, 256, 512};//网格划分参数，2的整次幂
    private static final int [] Top_Ks = {3, 6, 9, 12, 15, 18};
    private static final double [] bandwidth_ratio = {0.05, 0.10, 0.15, 0.20, 0.25};//KDE的带宽
    private static final double [] ks = {0.2, 0.4, 0.6, 0.8, 1.0, 1.2};//过滤参数
    private static final int iterations = 30;


    public static void main(String[] args) {
        int Top_K = 5;
        double k = 0.4;
        int resolution = 256;
        double alpha = 0.2;

        for (int a = 0; a < ks.length; a++) {
            k = ks[a];

            String directoryPath = "C:\\Users\\86151\\Desktop\\论文\\数据\\XYConverter public 0-1000";
            String pdfFilePath = directoryPath + "_PDFs_3h_" + resolution + "_" + alpha + ".ser"; // 定义保存路径

            List<Map<GridIndex, Double>> PDFs;
            File pdfFile = new File(pdfFilePath);
            if (pdfFile.exists()) {
                // 如果文件存在，加载 PDFs
                PDFs = DataPersistence.loadPDFsFromFile(pdfFilePath);
            } else {
                // 否则执行计算并保存 PDFs
                List<List<Double[]>> dataWarehouse = readCsvFilesFromDirectory(directoryPath);
                List<Map<GridIndex, Integer>> gridCounts = gridCounts(dataWarehouse, resolution);
                PDFs = calculateKDE(gridCounts, resolution, alpha, new GaussianKernel());
                //if (alpha == resolution * 0.12) {
                DataPersistence.savePDFsToFile(PDFs, pdfFilePath);  // 保存 PDFs
                //}
            }

            System.out.println("resolution: " + resolution);
            System.out.println("alpha: " + alpha);
            System.out.println();

            Map<Integer, double[]> stats = calculateHilbertStats(PDFs, resolution);
            buildIndexTree(stats);

            Random random = new Random(42); // 随机数生成器

            System.out.println("过滤参数k: " + k);

//            double totalOptimizationPercentage = 0; // 优化时间百分比总和
            double totalAccuracy = 0; // 累计准确性
            double totalBaselineTime = 0; // 累计基线搜索时间
            double totalOptimizedTime = 0; // 累计优化搜索时间

            for (int i = 0; i < iterations; i++) {
                int sampleIdx = random.nextInt(PDFs.size());
                Map<GridIndex, Double> sample = PDFs.get(sampleIdx);

                // 顺序搜索时间
                long startTime = System.nanoTime();
                List<DatasetSimilarity> baselineResults = findTopKSimilar(PDFs, sample, Top_K);
                long endTime = System.nanoTime();
                double baselineTime = (endTime - startTime) / 1_000_000.0;
                totalBaselineTime += baselineTime; // 累加基线搜索时间

                // 优化搜索时间
                double[] sampleStats = stats.get(sampleIdx);
                double targetMean = sampleStats[0];
                double targetVariance = sampleStats[1];
                long startTime2 = System.nanoTime();
                List<Integer> candidates = filterCandidates(targetMean, targetVariance, k);
                List<DatasetSimilarity> optimizedResults = findTopKWithCandidates(sample, PDFs, candidates, Top_K);
                long endTime2 = System.nanoTime();
                double optimizedTime = (endTime2 - startTime2) / 1_000_000.0;
                totalOptimizedTime += optimizedTime; // 累加优化搜索时间

//                // 优化后的运行时间是基线运行时间的百分比
//                double optimizationPercentage = (optimizedTime / baselineTime) * 100;
//                totalOptimizationPercentage += optimizationPercentage;

                // 提取索引号
                List<Integer> baselineIndices = baselineResults.stream().map(ds -> ds.index).collect(Collectors.toList());
                List<Integer> optimizedIndices = optimizedResults.stream().map(ds -> ds.index).collect(Collectors.toList());
                // 计算准确性
                Set<Integer> baselineSet = new HashSet<>(baselineIndices);
                Set<Integer> optimizedSet = new HashSet<>(optimizedIndices);
                baselineSet.retainAll(optimizedSet);
                double accuracy = (double) baselineSet.size() / Math.min(baselineIndices.size(), optimizedIndices.size());
                totalAccuracy += accuracy;

            }

            // 输出平均结果
//            double averageOptimization = totalOptimizationPercentage / iterations;
            double averageAccuracy = totalAccuracy / iterations * 100;
            double averageBaselineTime = totalBaselineTime / iterations; // 平均基线时间
            double averageOptimizedTime = totalOptimizedTime / iterations; // 平均优化时间

//            System.out.printf("Average Optimized Time as Percentage of Baseline: %.2f%%\n", averageOptimization);
            System.out.printf("Average Baseline Search Time: %.2f ms\n", averageBaselineTime);
            System.out.printf("Average Optimized Search Time: %.2f ms\n", averageOptimizedTime);
            System.out.printf("Average Accuracy: %.2f%%\n", averageAccuracy);
        }

    }

    // 获取当前JVM内存使用情况的方法
    public static long getUsedMemory() {
        Runtime runtime = Runtime.getRuntime();
        return runtime.totalMemory() - runtime.freeMemory();
    }

    public static List<DatasetSimilarity> findTopKWithCandidates(
            Map<GridIndex, Double> sample,
            List<Map<GridIndex, Double>> PDFs,
            List<Integer> candidates,
            int k
    ) {
        // 使用优先队列维护 Top-K 结果
        PriorityQueue<DatasetSimilarity> topK = new PriorityQueue<>(
                Comparator.comparingDouble(ds -> -ds.jsd) // 按 JSD 从大到小排序
        );

        for (int candidateIndex : candidates) {
            Map<GridIndex, Double> candidatePDF = PDFs.get(candidateIndex);

            // 计算 JSD
            double jsd = Similarity_Calculator.calculateJSD(sample, candidatePDF);

            // 构造 DatasetSimilarity 对象
            DatasetSimilarity similarity = new DatasetSimilarity(candidateIndex, candidatePDF, jsd);

            // 动态维护前 K 个最优解
            if (topK.size() < k) {
                topK.add(similarity); // 未达到 K 个时直接加入
            } else if (jsd < topK.peek().jsd) {
                // 如果当前 JSD 小于堆中最大 JSD，则替换最差解
                topK.poll();
                topK.add(similarity);
            }
        }

        // 转换为列表并按 JSD 从小到大排序
        List<DatasetSimilarity> result = new ArrayList<>(topK);
        result.sort(Comparator.comparingDouble(ds -> ds.jsd));
        return result;
    }


    // 查找最相似的前k个数据集并保留索引信息
    public static List<DatasetSimilarity> findTopKSimilar(
            List<Map<GridIndex, Double>> datasets, // 稀疏概率分布
            Map<GridIndex, Double> sample, // 样本分布
            int k) {
        PriorityQueue<DatasetSimilarity> topK = new PriorityQueue<>(
                Comparator.comparingDouble(ds -> -ds.jsd) // 从大到小排序
        );

        for (int i = 0; i < datasets.size(); i++) {
            Map<GridIndex, Double> dataset = datasets.get(i);
            double jsd = Similarity_Calculator.calculateJSD(sample, dataset); // 使用稀疏概率分布计算JSD
            DatasetSimilarity ds = new DatasetSimilarity(i, dataset, jsd);

            if (topK.size() < k) {
                topK.add(ds);
            } else if (jsd < topK.peek().jsd) {
                topK.poll(); // 移除最差相似度的数据集
                topK.add(ds); // 加入新的更相似的数据集
            }
        }

        // 将结果从PriorityQueue转为列表并排序
        List<DatasetSimilarity> result = new ArrayList<>(topK);
        result.sort(Comparator.comparingDouble(ds -> ds.jsd));
        return result;
    }

}
// 提取 JSD 值
//                List<Double> baselineJSDs = baselineResults.stream().map(ds -> ds.jsd).collect(Collectors.toList());
//                List<Double> optimizedJSDs = optimizedResults.stream().map(ds -> ds.jsd).collect(Collectors.toList());
//                // 计算 JSD 交集
//                Set<Double> baselineSet = new HashSet<>(baselineJSDs);
//                Set<Double> optimizedSet = new HashSet<>(optimizedJSDs);
//                baselineSet.retainAll(optimizedSet);
//                double accuracy = (double) baselineSet.size() / Math.min(baselineJSDs.size(), optimizedJSDs.size());
//                totalAccuracy += accuracy;

//                // 离散化
//                List<Double> roundedBaselineJSDs = baselineResults.stream()
//                        .map(ds -> Math.round(ds.jsd * 1e6) / 1e6)
//                        .collect(Collectors.toList());
//                List<Double> roundedOptimizedJSDs = optimizedResults.stream()
//                        .map(ds -> Math.round(ds.jsd * 1e6) / 1e6)
//                        .collect(Collectors.toList());
//                Set<Double> baselineSet = new HashSet<>(roundedBaselineJSDs);
//                Set<Double> optimizedSet = new HashSet<>(roundedOptimizedJSDs);
//                baselineSet.retainAll(optimizedSet);
//                double accuracy = (double) baselineSet.size() / Math.min(roundedBaselineJSDs.size(), roundedOptimizedJSDs.size());
//                totalAccuracy += accuracy;

//                // 输出当前循环信息
//                System.out.printf("Iteration %d: Baseline time = %.2f ms, Optimized time = %.2f ms, Optimization = %.2f%%, Accuracy = %.2f%%\n",
//                        i + 1, baselineTime, optimizedTime, optimizationPercentage, accuracy);