package Similarity_Model;

import java.util.*;

public class Index {

    private static TreeNode root = null; // 索引树根节点

    // Hilbert编码实现
    private static long calculateHilbertCode(int x, int y, int maxBits) {
        long hilbert = 0; // 编码值
        int mask = (1 << maxBits) - 1; // 用于限制范围的掩码
        int halfSize = 1 << (maxBits - 1); // 处理每一级大小的一半
        int[] h = {0, 1, 3, 2}; // Hilbert映射表

        for (int s = halfSize; s > 0; s /= 2) {
            int rx = (x & s) > 0 ? 1 : 0; // 当前层水平位
            int ry = (y & s) > 0 ? 1 : 0; // 当前层垂直位
            int idx = 2 * rx + ry; // 当前区域的编码
            hilbert = (hilbert << 2) + h[idx]; // 更新Hilbert编码

            // 旋转逻辑
            if (ry == 0) {
                if (rx == 1) {
                    x = mask - x;
                    y = mask - y;
                }
                // 交换 x 和 y
                int temp = x;
                x = y;
                y = temp;
            }
        }
        return hilbert;
    }

    private static long calculateHilbertCode(GridIndex index, int maxResolution) {
        int maxBits = Integer.SIZE - Integer.numberOfLeadingZeros(maxResolution - 1);
        return calculateHilbertCode(index.x, index.y, maxBits);
    }

    // 计算Hilbert编码均值和方差
    public static Map<Integer, double[]> calculateHilbertStats(List<Map<GridIndex, Double>> PDFs, int maxResolution) {
        Map<Integer, double[]> stats = new HashMap<>();
        for (int datasetIndex = 0; datasetIndex < PDFs.size(); datasetIndex++) {
            Map<GridIndex, Double> pdf = PDFs.get(datasetIndex);

            double sumWeights = 0;
            double weightedSum = 0;
            double weightedSumSq = 0;

            for (Map.Entry<GridIndex, Double> entry : pdf.entrySet()) {
                GridIndex index = entry.getKey();
                double probability = entry.getValue();

                long hilbertCode = calculateHilbertCode(index, maxResolution);
                weightedSum += hilbertCode * probability;
                weightedSumSq += hilbertCode * hilbertCode * probability;
                sumWeights += probability;
            }

            double mean = weightedSum / sumWeights;
            double variance = (weightedSumSq / sumWeights) - mean * mean;

            stats.put(datasetIndex, new double[]{mean, variance});
        }
        return stats;
    }

    // 构建索引树
    public static void buildIndexTree(Map<Integer, double[]> hilbertStats) {
        List<TreeNode> nodes = new ArrayList<>();
        for (Map.Entry<Integer, double[]> entry : hilbertStats.entrySet()) {
            int datasetIndex = entry.getKey();
            double mean = entry.getValue()[0];
            nodes.add(new TreeNode(mean, datasetIndex));
        }

        // 按均值排序
        nodes.sort(Comparator.comparingDouble(node -> node.mean));
        root = constructBalancedTree(nodes, 0, nodes.size() - 1);
    }

    private static TreeNode constructBalancedTree(List<TreeNode> nodes, int start, int end) {
        if (start > end) return null;

        int mid = (start + end) / 2;
        TreeNode node = nodes.get(mid);
        node.left = constructBalancedTree(nodes, start, mid - 1);
        node.right = constructBalancedTree(nodes, mid + 1, end);

        return node;
    }

    // 根据切比雪夫不等式进行候选集过滤
    public static List<Integer> filterCandidates(double targetMean, double targetVariance, double k) {
        List<Integer> candidates = new ArrayList<>();
        double range = k * Math.sqrt(targetVariance); // 切比雪夫范围
//        System.out.println("targetVariance = " + targetVariance);
//        System.out.println("range = " + range);

        queryTree(root, targetMean, range, candidates);
        return candidates;
    }

    private static void queryTree(TreeNode node, double targetMean, double range, List<Integer> candidates) {
        if (node == null) return;

        if (Math.abs(node.mean - targetMean) <= range) {
            candidates.add(node.datasetIndex);
        }

        if (targetMean - range < node.mean) {
            queryTree(node.left, targetMean, range, candidates);
        }
        if (targetMean + range > node.mean) {
            queryTree(node.right, targetMean, range, candidates);
        }
    }

}

// 二叉平衡树节点
class TreeNode {
    double mean; // Hilbert编码均值
    int datasetIndex; // 数据集索引
    TreeNode left, right;

    TreeNode(double mean, int datasetIndex) {
        this.mean = mean;
        this.datasetIndex = datasetIndex;
    }
}
