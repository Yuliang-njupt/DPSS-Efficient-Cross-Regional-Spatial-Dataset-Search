package Similarity_Model;

import java.io.File;
import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.Collectors;

import static Similarity_Model.Probability_density_distribution.*;
import static Similarity_Model.Read_Files.readCsvFilesFromDirectory;
import static Similarity_Model.Index.*;

public class sample_test {
    public static List<Map<GridIndex, Integer>> initializeGrids() {
        List<Map<GridIndex, Integer>> gridCounts = new ArrayList<>();

        // 初始化第一组数据（图b）
        Map<GridIndex, Integer> map1 = new HashMap<>();
        int[][] data1 = {
                {0, 0, 2, 0},
                {0, 0, 2, 0},
                {0, 0, 2, 0},
                {2, 2, 0, 0}
        };
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                if (data1[row][col] != 0)
                    map1.put(new GridIndex(row, col), data1[row][col]);
            }
        }
        gridCounts.add(map1);

        // 初始化第二组数据
        Map<GridIndex, Integer> map2 = new HashMap<>();
        int[][] data2 = {
                {0, 0, 0, 2},
                {0, 0, 0, 2},
                {0, 1, 2, 0},
                {2, 1, 0, 0}
        };
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                if (data2[row][col] != 0)
                    map2.put(new GridIndex(row, col), data2[row][col]);
            }
        }
        gridCounts.add(map2);

        return gridCounts;
    }

    public static void main(String[] args) {
        int resolution = 4;
        double alpha = 0.2;
        List<Map<GridIndex, Integer>> gridCounts = initializeGrids();
        List<Map<GridIndex, Double>> PDFs = calculateKDE(gridCounts, resolution, alpha, new GaussianKernel());

        // 创建 DecimalFormat 对象，用于保留两位小数
        DecimalFormat df = new DecimalFormat("#.00");

        // 遍历 PDFs 列表
        for (int i = 0; i < PDFs.size(); i++) {
            System.out.println("第 " + (i + 1) + " 组数据的概率密度分布:");
            Map<GridIndex, Double> pdfMap = PDFs.get(i);
            // 遍历每个 Map 中的 GridIndex 和对应的概率密度值
            for (Map.Entry<GridIndex, Double> entry : pdfMap.entrySet()) {
                GridIndex index = entry.getKey();
                double pdfValue = entry.getValue();
                System.out.println("GridIndex(" + index.x + ", " + index.y + ") 的概率密度: " + df.format(pdfValue));
            }
            System.out.println();
        }
    }
}