package Similarity_Model;

import java.util.*;

public class Similarity_Calculator {
    private Similarity_Calculator() {}

    // MSE
    public static double calculateMSE(Map<GridIndex, Double> p, Map<GridIndex, Double> q) {
        double mse = 0.0;
        // 获取所有涉及到的网格索引并去重
        Set<GridIndex> allIndices = new HashSet<>(p.keySet());
        allIndices.addAll(q.keySet());

        for (GridIndex index : allIndices) {
            double pVal = p.getOrDefault(index, 0.0);
            double qVal = q.getOrDefault(index, 0.0);
            double diff = pVal - qVal;
            mse += diff * diff;
        }
        return mse / allIndices.size();
    }


    //轮廓系数
    public static double calculateSilhouetteCoefficient(Map<Pair<Integer>, Double> jsdCache, List<Integer> topKIndices, List<Integer> contrastIndices) {
        double totalSilhouette = 0.0;

        int cnt0 = 0;
        for (int currentIdx : topKIndices) {

            // 计算a(i)：与同簇其他样本的平均距离
            double a = topKIndices.stream()
                    .filter(idx -> idx != currentIdx)
                    .mapToDouble(idx -> {
                        Double jsd = jsdCache.get(new Pair(currentIdx, idx));
                        return jsd != null && !Double.isNaN(jsd) ? jsd : 0.0;
                    })
                    .average()
                    .orElse(0.0);

            // 计算b(i)：与对比簇的平均距离
            double b = contrastIndices.stream()
                    .mapToDouble(idx -> {
                        Double jsd = jsdCache.get(new Pair(currentIdx, idx));
                        return jsd != null && !Double.isNaN(jsd) ? jsd : 0.0;
                    })
                    .average()
                    .orElse(0.0);

            // 处理a和b均为0的情况，避免除以零
            if (a == 0 && b == 0) {
                totalSilhouette += 0.0;
                cnt0 ++ ;
            } else {
                double s = (b - a) / Math.max(a, b);
                totalSilhouette += s;
            }
        }
        if (cnt0 != 0) System.out.println(cnt0);

        return totalSilhouette / (topKIndices.size());
    }

    //密度重叠法
    public static double calculateOverlapDensity(Map<GridIndex, Double> p, Map<GridIndex, Double> q) {
        double similarity = 0.0;

        // 遍历两个分布共有的键
        for (GridIndex index : p.keySet()) {
            if (q.containsKey(index)) {
                // 取两个分布对应值的最小值
                similarity += Math.min(p.get(index), q.get(index));
            }
        }

        return 1 - similarity;
    }

    // 计算 Jensen-Shannon 散度，map，避免mval=0
    public static double calculateJSD(Map<GridIndex, Double> p, Map<GridIndex, Double> q) {
        Map<GridIndex, Double> m = new HashMap<>();

        // 构建联合分布 M = (P + Q) / 2
        for (GridIndex index : p.keySet()) {
            m.put(index, p.getOrDefault(index, 0.0) / 2.0);
        }
        for (GridIndex index : q.keySet()) {
            m.put(index, m.getOrDefault(index, 0.0) + q.getOrDefault(index, 0.0) / 2.0);
        }

        // 计算 KL(P || M) 和 KL(Q || M)
        double klP = 0.0, klQ = 0.0;
        for (GridIndex index : m.keySet()) {
            double mVal = m.get(index);
            double pVal = p.getOrDefault(index, 0.0);
            double qVal = q.getOrDefault(index, 0.0);

            if (mVal > 0) {
                if (pVal > 0) {
                    klP += pVal * (Math.log(pVal / mVal) / Math.log(2));  // 以2为底
                }
                if (qVal > 0) {
                    klQ += qVal * (Math.log(qVal / mVal) / Math.log(2));  // 以2为底
                }
            } else {
                // mVal 为 0 时，将贡献值设为 0
                if (pVal > 0) {
                    klP += 0;
                }
                if (qVal > 0) {
                    klQ += 0;
                }
            }
        }


        // JSD = 0.5 * (KL(P || M) + KL(Q || M))
        return 0.5 * (klP + klQ);
    }

    public static double calculateCosineSimilarity(double[][] a, double[][] b) {
        double dotProduct = 0.0;
        double normA = 0.0;
        double normB = 0.0;

        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                dotProduct += a[i][j] * b[i][j];
                normA += a[i][j] * a[i][j];
                normB += b[i][j] * b[i][j];
            }
        }

        if (normA == 0.0 || normB == 0.0) {
            return 0.0;
        }

        return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    }

}
