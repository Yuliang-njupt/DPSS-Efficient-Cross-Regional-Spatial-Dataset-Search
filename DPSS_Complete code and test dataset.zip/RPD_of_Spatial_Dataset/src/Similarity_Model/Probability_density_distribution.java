package Similarity_Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.*;
import java.util.stream.Collectors;

public class Probability_density_distribution {
    private Probability_density_distribution() {}

    //二维数组
//    public static List<int[][]> gridCounts(List<List<Double[]>> spatialDataWarehouse, int resolution) {
//        List<int[][]> originalFeatures = new ArrayList<>();
//
//        for (List<Double[]> dataset : spatialDataWarehouse) {
//            int[][] gridFeatures = new int[resolution][resolution];
//
//            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
//            for (Double[] point : dataset) {
//                minX = Math.min(minX, point[0]);
//                minY = Math.min(minY, point[1]);
//                maxX = Math.max(maxX, point[0]);
//                maxY = Math.max(maxY, point[1]);
//            }
//
//            double gridSizeX = (maxX - minX) / resolution;
//            double gridSizeY = (maxY - minY) / resolution;
//            double gridSize = Math.max(gridSizeX, gridSizeY);
//            gridSize = Math.max(gridSize, 0.00000001);
//
//            double offsetX = (resolution - (maxX - minX) / gridSize) / 2 * gridSize;
//            double offsetY = (resolution - (maxY - minY) / gridSize) / 2 * gridSize;
//
//            for (Double[] point : dataset) {
//                int gridX = (int) ((point[0] - minX + offsetX) / gridSize);
//                int gridY = (int) ((point[1] - minY + offsetY) / gridSize);
//                if (gridX >= resolution) gridX--;
//                if (gridY >= resolution) gridY--;
//                gridFeatures[gridX][gridY]++;
//            }
//
//            originalFeatures.add(gridFeatures);
//            gridFeatures = null;
//        }
//        return originalFeatures;
//    }

    // 由最值确定边界
//    public static List<Map<GridIndex, Integer>> gridCounts(List<List<Double[]>> spatialDataWarehouse, int resolution) {
//        // 存储所有数据集的稀疏网格
//        List<Map<GridIndex, Integer>> originalFeatures = new ArrayList<>();
//
//        // 遍历每个数据集
//        for (List<Double[]> dataset : spatialDataWarehouse) {
//            // 使用 Map 存储稀疏网格
//            Map<GridIndex, Integer> sparseGrid = new HashMap<>();
//
//            // 初始化边界值
//            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE;
//            double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
//
//            // 计算数据集的边界值
//            for (Double[] point : dataset) {
//                minX = Math.min(minX, point[0]);
//                minY = Math.min(minY, point[1]);
//                maxX = Math.max(maxX, point[0]);
//                maxY = Math.max(maxY, point[1]);
//            }
//
//            // 计算网格大小
//            double gridSizeX = (maxX - minX) / resolution;
//            double gridSizeY = (maxY - minY) / resolution;
//            double gridSize = Math.max(gridSizeX, gridSizeY);
//            gridSize = Math.max(gridSize, 0.00000001); // 避免除以零
//
//            // 计算偏移量以使数据在网格中居中
//            double offsetX = (resolution - (maxX - minX) / gridSize) / 2 * gridSize;
//            double offsetY = (resolution - (maxY - minY) / gridSize) / 2 * gridSize;
//
//            // 将数据点映射到网格并更新计数
//            for (Double[] point : dataset) {
//                int gridX = (int) ((point[0] - minX + offsetX) / gridSize); // 计算网格的 X 索引
//                int gridY = (int) ((point[1] - minY + offsetY) / gridSize); // 计算网格的 Y 索引
//                if (gridX >= resolution) gridX--; // 防止越界
//                if (gridY >= resolution) gridY--; // 防止越界
//
//                GridIndex key = new GridIndex(gridX, gridY);
//                sparseGrid.put(key, sparseGrid.getOrDefault(key, 0) + 1);
//
//            }
//
//            // 将当前数据集的稀疏网格添加到结果列表
//            originalFeatures.add(sparseGrid);
//        }
//
//        // 返回所有数据集的稀疏网格
//        return originalFeatures;
//    }

    //质心对齐
    public static List<Map<GridIndex, Integer>> gridCounts(List<List<Double[]>> spatialDataWarehouse, int resolution) {
        // 存储所有数据集的稀疏网格
        List<Map<GridIndex, Integer>> originalFeatures = new ArrayList<>();

        // 遍历每个数据集
        for (List<Double[]> dataset : spatialDataWarehouse) {
            // 使用 Map 存储稀疏网格
            Map<GridIndex, Integer> sparseGrid = new HashMap<>();

            // 1. 计算点集的质心
            double cx = 0, cy = 0;
            int n = dataset.size();
            for (Double[] point : dataset) {
                cx += point[0];
                cy += point[1];
            }
            cx /= n;
            cy /= n;

            // 2. 计算点集的尺度（范围）
            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE;
            double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            for (Double[] point : dataset) {
                minX = Math.min(minX, point[0]);
                minY = Math.min(minY, point[1]);
                maxX = Math.max(maxX, point[0]);
                maxY = Math.max(maxY, point[1]);
            }
            double rangeX = maxX - minX;
            double rangeY = maxY - minY;

            // 3. 标准化点集
            // 标准化到 [-1, 1] 范围
            for (Double[] point : dataset) {
                double newX;
                double newY;
                if (rangeX == 0) {
                    newX = 0; // 若所有点 x 坐标相同，标准化为 0
                } else {
                    newX = (point[0] - cx) / rangeX;
                }
                if (rangeY == 0) {
                    newY = 0; // 若所有点 y 坐标相同，标准化为 0
                } else {
                    newY = (point[1] - cy) / rangeY;
                }

                // 4. 将标准化点集映射到网格
                int gridX = (int) ((newX + 1) / 2 * resolution);
                int gridY = (int) ((newY + 1) / 2 * resolution);
                if (gridX >= resolution) gridX = resolution - 1; // 确保不超过最大值
                if (gridY >= resolution) gridY = resolution - 1;
                if (gridX < 0) gridX = 0; // 确保不小于最小值
                if (gridY < 0) gridY = 0;

                GridIndex key = new GridIndex(gridX, gridY);
                sparseGrid.put(key, sparseGrid.getOrDefault(key, 0) + 1);
            }

            // 将当前数据集的稀疏网格添加到结果列表
            originalFeatures.add(sparseGrid);
        }

        // 返回所有数据集的稀疏网格
        return originalFeatures;
    }


// 二维数组
//    public static List<double[][]> calculateKDE(List<int[][]> gridCounts, int resolution, double bandwidth, KernelFunction kernel) {
//        List<double[][]> probabilityDistributions = new ArrayList<>();
//
//        for (int[][] grid : gridCounts) {
//            double[][] probabilityDistribution = new double[resolution][resolution];
//
//            for (int x = 0; x < resolution; x++) {
//                for (int y = 0; y < resolution; y++) {
//                    double density = 0.0;
//                    for (int i = 0; i < resolution; i++) {
//                        for (int j = 0; j < resolution; j++) {
//                            double distanceSquared = Math.pow(x - i, 2) + Math.pow(y - j, 2);
//                            double weight = kernel.compute(distanceSquared, bandwidth);
//                            density += grid[i][j] * weight;
//                        }
//                    }
//                    probabilityDistribution[x][y] = density;
//                }
//            }
//
//            double sum = 0.0;
//            for (int x = 0; x < resolution; x++) {
//                for (int y = 0; y < resolution; y++) {
//                    sum += probabilityDistribution[x][y];
//                }
//            }
//            for (int x = 0; x < resolution; x++) {
//                for (int y = 0; y < resolution; y++) {
//                    probabilityDistribution[x][y] /= sum;
//                }
//            }
//
//            probabilityDistributions.add(probabilityDistribution);
//        }
//
//        return probabilityDistributions;
//    }

    //只计算数据点对周围3h范围的影响，二维数组
//    public static List<double[][]> calculateKDE(List<int[][]> gridCounts, int resolution, double bandwidth, KernelFunction kernel) {
//        List<double[][]> probabilityDistributions = new ArrayList<>();
//        int range = (int) Math.ceil(3 * bandwidth); // 计算影响范围的整数值
//
//        for (int[][] grid : gridCounts) {
//            double[][] probabilityDistribution = new double[resolution][resolution];
//
//            for (int i = 0; i < resolution; i++) {
//                for (int j = 0; j < resolution; j++) {
////                    //直方图
////                    probabilityDistribution[i][j] = grid[i][j];
//                    if (grid[i][j] == 0) continue; // 跳过零值点
//
//                    // 只计算当前点(i, j)的影响范围
//                    for (int x = Math.max(0, i - range); x < Math.min(resolution, i + range + 1); x++) {
//                        for (int y = Math.max(0, j - range); y < Math.min(resolution, j + range + 1); y++) {
//                            double distanceSquared = Math.pow(x - i, 2) + Math.pow(y - j, 2);
//                            if (distanceSquared <= 9 * Math.pow(bandwidth, 2)) { // 只在3h范围内计算
//                                double weight = kernel.compute(distanceSquared, bandwidth);
//                                probabilityDistribution[x][y] += grid[i][j] * weight;
//                            }
//                        }
//                    }
//                }
//            }
//
//            // 归一化处理
//            double sum = 0.0;
//            for (int x = 0; x < resolution; x++) {
//                for (int y = 0; y < resolution; y++) {
//                    sum += probabilityDistribution[x][y];
//                }
//            }
//            for (int x = 0; x < resolution; x++) {
//                for (int y = 0; y < resolution; y++) {
//                    probabilityDistribution[x][y] /= sum;
//                }
//            }
//
//            probabilityDistributions.add(probabilityDistribution);
//            probabilityDistribution = null;
//        }
//
//        return probabilityDistributions;
//    }

    public static List<Map<GridIndex, Double>> calculateDensity(
            List<Map<GridIndex, Integer>> sparseGridCounts
            ) {
        List<Map<GridIndex, Double>> probabilityDistributions = new ArrayList<>();

        for (Map<GridIndex, Integer> sparseGrid : sparseGridCounts) {
            // 计算所有网格点的总计数
            int totalCount = sparseGrid.values().stream().mapToInt(Integer::intValue).sum();

            Map<GridIndex, Double> probabilityDistribution = new HashMap<>();

            // 遍历稀疏网格中的非零点
            for (Map.Entry<GridIndex, Integer> entry : sparseGrid.entrySet()) {
                GridIndex gridIndex = entry.getKey();
                int count = entry.getValue();

                // 计算该网格点的密度
                double density = (double) count / totalCount;
                probabilityDistribution.put(gridIndex, density);
            }

            probabilityDistributions.add(probabilityDistribution);

            // 及时清理不需要的临时数据
            sparseGrid.clear();
        }

        return probabilityDistributions;
    }

    //3h
    public static List<Map<GridIndex, Double>> calculateKDE(
            List<Map<GridIndex, Integer>> sparseGridCounts,
            int resolution,
            double alpha,
            KernelFunction kernel) {
        List<Map<GridIndex, Double>> probabilityDistributions = new ArrayList<>();

        for (Map<GridIndex, Integer> sparseGrid : sparseGridCounts) {
            // 计算所有网格点计数的中位数
            List<Integer> counts = new ArrayList<>(sparseGrid.values());
            double median = calculateMedian(counts);

            Map<GridIndex, Double> probabilityDistribution = new HashMap<>();

            // 遍历稀疏网格中的非零点
            for (Map.Entry<GridIndex, Integer> entry : sparseGrid.entrySet()) {
                GridIndex gridIndex = entry.getKey();
                int count = entry.getValue();
                int i = gridIndex.x;
                int j = gridIndex.y;

                // 计算自适应带宽
                double bandwidth = Math.pow(count / median, -alpha);
                int range = (int) Math.ceil(3 * bandwidth);
                //range = 0;//相当于noKDE

                // 只计算当前点(i, j)的影响范围
                for (int x = Math.max(0, i - range); x < Math.min(resolution, i + range + 1); x++) {
                    for (int y = Math.max(0, j - range); y < Math.min(resolution, j + range + 1); y++) {
                        double distanceSquared = Math.pow(x - i, 2) + Math.pow(y - j, 2);
                        if (distanceSquared <= 9 * Math.pow(bandwidth, 2)) { // 只在3h范围内计算
                            double weight = kernel.compute(distanceSquared, bandwidth);
                            GridIndex targetIndex = new GridIndex(x, y);
                            probabilityDistribution.put(
                                    targetIndex,
                                    probabilityDistribution.getOrDefault(targetIndex, 0.0) + count * weight
                            );
                        }
                    }
                }
            }

            // 归一化处理
            double sum = probabilityDistribution.values().stream().mapToDouble(Double::doubleValue).sum();
            for (Map.Entry<GridIndex, Double> entry : probabilityDistribution.entrySet()) {
                probabilityDistribution.put(entry.getKey(), entry.getValue() / sum);
            }

            probabilityDistributions.add(probabilityDistribution);

            // 及时清理不需要的临时数据
            sparseGrid.clear();
        }

        return probabilityDistributions;
    }

    //全局
    public static List<Map<GridIndex, Double>> calculateKDEGlobal(
            List<Map<GridIndex, Integer>> sparseGridCounts,
            int resolution,
            double alpha,
            KernelFunction kernel) {
        List<Map<GridIndex, Double>> probabilityDistributions = new ArrayList<>();

        for (Map<GridIndex, Integer> sparseGrid : sparseGridCounts) {
            // 计算所有网格点计数的中位数
            List<Integer> counts = new ArrayList<>(sparseGrid.values());
            double median = calculateMedian(counts);

            Map<GridIndex, Double> probabilityDistribution = new HashMap<>();

            // 遍历稀疏网格中的非零点
            for (Map.Entry<GridIndex, Integer> entry : sparseGrid.entrySet()) {
                GridIndex gridIndex = entry.getKey();
                int count = entry.getValue();
                int i = gridIndex.x;
                int j = gridIndex.y;

                // 计算自适应带宽
                double bandwidth = Math.pow(count / median, -alpha);

                // 遍历整个网格
                for (int x = 0; x < resolution; x++) {
                    for (int y = 0; y < resolution; y++) {
                        double distanceSquared = Math.pow(x - i, 2) + Math.pow(y - j, 2);
                        double weight = kernel.compute(distanceSquared, bandwidth);
                        GridIndex targetIndex = new GridIndex(x, y);
                        probabilityDistribution.put(
                                targetIndex,
                                probabilityDistribution.getOrDefault(targetIndex, 0.0) + count * weight
                        );
                    }
                }
            }

            // 归一化处理
            double sum = probabilityDistribution.values().stream().mapToDouble(Double::doubleValue).sum();
            for (Map.Entry<GridIndex, Double> entry : probabilityDistribution.entrySet()) {
                probabilityDistribution.put(entry.getKey(), entry.getValue() / sum);
            }

            probabilityDistributions.add(probabilityDistribution);

            // 及时清理不需要的临时数据
            sparseGrid.clear();
        }

        return probabilityDistributions;
    }


    // 计算中位数的辅助方法
    private static double calculateMedian(List<Integer> values) {
        int size = values.size();
        if (size == 0) {
            return 0;
        }
        List<Integer> sortedValues = values.stream().sorted().collect(Collectors.toList());
        if (size % 2 == 0) {
            return (sortedValues.get(size / 2 - 1) + sortedValues.get(size / 2)) / 2.0;
        } else {
            return sortedValues.get(size / 2);
        }
    }

    //3h范围，map
//    public static List<Map<GridIndex, Double>> calculateKDE(
//            List<Map<GridIndex, Integer>> sparseGridCounts,
//            int resolution,
//            double bandwidth,
//            KernelFunction kernel) {
//        List<Map<GridIndex, Double>> probabilityDistributions = new ArrayList<>();
//        int range = (int) Math.ceil(3 * bandwidth); // 计算影响范围的整数值
//
//        for (Map<GridIndex, Integer> sparseGrid : sparseGridCounts) {
//            Map<GridIndex, Double> probabilityDistribution = new HashMap<>();
//
//            // 遍历稀疏网格中的非零点
//            for (Map.Entry<GridIndex, Integer> entry : sparseGrid.entrySet()) {
//                GridIndex gridIndex = entry.getKey();
//                int count = entry.getValue();
//                int i = gridIndex.x;
//                int j = gridIndex.y;
//
//                // 只计算当前点(i, j)的影响范围
//                for (int x = Math.max(0, i - range); x < Math.min(resolution, i + range + 1); x++) {
//                    for (int y = Math.max(0, j - range); y < Math.min(resolution, j + range + 1); y++) {
//                        double distanceSquared = Math.pow(x - i, 2) + Math.pow(y - j, 2);
//                        if (distanceSquared <= 9 * Math.pow(bandwidth, 2)) { // 只在3h范围内计算
//                            double weight = kernel.compute(distanceSquared, bandwidth);
//                            GridIndex targetIndex = new GridIndex(x, y);
//                            probabilityDistribution.put(
//                                    targetIndex,
//                                    probabilityDistribution.getOrDefault(targetIndex, 0.0) + count * weight
//                            );
//                        }
//                    }
//                }
//            }
//
//            // 归一化处理
//            double sum = probabilityDistribution.values().stream().mapToDouble(Double::doubleValue).sum();
//            for (Map.Entry<GridIndex, Double> entry : probabilityDistribution.entrySet()) {
//                probabilityDistribution.put(entry.getKey(), entry.getValue() / sum);
//            }
//
//            probabilityDistributions.add(probabilityDistribution);
//
//            // 及时清理不需要的临时数据
//            sparseGrid.clear();
//        }
//
//        return probabilityDistributions;
//    }

    // 全局范围，map
//    public static List<Map<GridIndex, Double>> calculateKDEGlobal(
//            List<Map<GridIndex, Integer>> sparseGridCounts,
//            int resolution,
//            double bandwidth,
//            KernelFunction kernel) {
//        List<Map<GridIndex, Double>> probabilityDistributions = new ArrayList<>();
//
//        for (Map<GridIndex, Integer> sparseGrid : sparseGridCounts) {
//            Map<GridIndex, Double> probabilityDistribution = new HashMap<>();
//
//            // 遍历稀疏网格中的非零点
//            for (Map.Entry<GridIndex, Integer> entry : sparseGrid.entrySet()) {
//                GridIndex gridIndex = entry.getKey();
//                int count = entry.getValue();
//                int i = gridIndex.x;
//                int j = gridIndex.y;
//
//                // 遍历整个网格
//                for (int x = 0; x < resolution; x++) {
//                    for (int y = 0; y < resolution; y++) {
//                        double distanceSquared = Math.pow(x - i, 2) + Math.pow(y - j, 2);
//                        double weight = kernel.compute(distanceSquared, bandwidth);
//                        GridIndex targetIndex = new GridIndex(x, y);
//                        probabilityDistribution.put(
//                                targetIndex,
//                                probabilityDistribution.getOrDefault(targetIndex, 0.0) + count * weight
//                        );
//                    }
//                }
//            }
//
//            // 归一化处理
//            double sum = probabilityDistribution.values().stream().mapToDouble(Double::doubleValue).sum();
//            for (Map.Entry<GridIndex, Double> entry : probabilityDistribution.entrySet()) {
//                probabilityDistribution.put(entry.getKey(), entry.getValue() / sum);
//            }
//
//            probabilityDistributions.add(probabilityDistribution);
//
//            // 及时清理不需要的临时数据
//            sparseGrid.clear();
//        }
//
//        return probabilityDistributions;
//    }


    public interface KernelFunction {
        double compute(double distanceSquared, double bandwidth);
    }

    //简化版，但对结果不会有影响
    public static class GaussianKernel implements KernelFunction {
        @Override
        public double compute(double distanceSquared, double bandwidth) {
            double hSquared = Math.pow(bandwidth, 2);
            return Math.exp(-distanceSquared / (2 * hSquared)) / (2 * Math.PI * hSquared);
        }
    }
}

//class GridIndex {
//    int x, y;
//
//    GridIndex(int x, int y) {
//        this.x = x;
//        this.y = y;
//    }
//
//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        GridIndex that = (GridIndex) o;
//        return x == that.x && y == that.y;
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(x, y);
//    }
//}

class GridIndex implements Serializable {  // 实现 Serializable 接口
    private static final long serialVersionUID = 1L;  // 可选

    int x, y;

    // 构造函数
    GridIndex(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // 重写 equals 方法
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GridIndex that = (GridIndex) o;
        return x == that.x && y == that.y;
    }

    // 重写 hashCode 方法
    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }
}


