package Similarity_Model;

import java.io.File;
import java.util.*;

import static Similarity_Model.Probability_density_distribution.*;
import static Similarity_Model.Read_Files.readCsvFilesFromDirectory;
import static Similarity_Model.Index.*;

public class Test {
    private static final int resolution = 32;//网格划分参数，2的整次幂
    private static final int Top_K = 10;
    private static final double bandwidth = 5;//KDE的带宽
    private static final double k = 0.4;//过滤参数
    private static final int sampleidx = 888;//范例数据集索引号

    public static void main(String[] args) {
        String directoryPath = "C:\\Users\\86151\\Desktop\\论文\\数据\\XYConverter public 0-1000";
        String pdfFilePath = directoryPath + "_PDFs_" + resolution + "_" + bandwidth + ".ser"; // 定义保存路径

        List<Map<GridIndex, Double>> PDFs;

        File pdfFile = new File(pdfFilePath);
        if (pdfFile.exists()) {
            // 如果文件存在，加载 PDFs
            PDFs = DataPersistence.loadPDFsFromFile(pdfFilePath);
        } else {
            // 否则执行计算并保存 PDFs
            List<List<Double[]>> dataWarehouse = readCsvFilesFromDirectory(directoryPath);
            List<Map<GridIndex, Integer>> gridCounts = gridCounts(dataWarehouse, resolution);
            PDFs = calculateKDE(gridCounts, resolution, bandwidth, new GaussianKernel());
            DataPersistence.savePDFsToFile(PDFs, pdfFilePath);  // 保存 PDFs
        }

        System.out.println("resolution: " + resolution);
        System.out.println("bandwidth: " + bandwidth);
        System.out.println("过滤参数k: " + k);

        final Map<GridIndex, Double> sample = PDFs.get(sampleidx);

        // 输出初始内存使用情况
        System.out.println("初始内存使用情况:");
        PrintMenory();

        long startTime = System.nanoTime(); // 开始计时
        List<DatasetSimilarity> topKSimilar = findTopKSimilar(PDFs, sample, Top_K);
        long endTime = System.nanoTime(); // 结束计时
        double elapsedTimeInMillis = (endTime - startTime) / 1_000_000.0; // 转换为毫秒
        System.out.println("Baseline 代码运行时间: " + elapsedTimeInMillis + " 毫秒");

        // 输出 Baseline 方法后的内存使用情况
        System.out.println("Baseline 方法后的内存使用情况:");
        PrintMenory();

        Map<Integer, double[]> stats = calculateHilbertStats(PDFs, resolution);

        double[] sampleStats = stats.get(sampleidx);
        double targetMean = sampleStats[0];     // 使用 sample 的均值
        double targetVariance = sampleStats[1]; // 使用 sample 的方差
        buildIndexTree(stats);

        long startTime2 = System.nanoTime(); // 开始计时
        List<Integer> candidates = filterCandidates(targetMean, targetVariance, k);
        List<DatasetSimilarity> topKSimilar2 = findTopKWithCandidates(sample, PDFs, candidates, Top_K);
        long endTime2 = System.nanoTime(); // 结束计时
        double elapsedTimeInMillis2 = (endTime2 - startTime2) / 1_000_000.0; // 转换为毫秒
        System.out.println("Optimized 代码运行时间: " + elapsedTimeInMillis2 + " 毫秒");

        // 输出 Optimized 方法后的内存使用情况
        System.out.println("Optimized 方法后的内存使用情况:");
        PrintMenory();

        System.out.println("数据库大小：" + PDFs.size());
        System.out.println("candidates size : " + candidates.size());
        System.out.println("sampleidx : " + sampleidx + " : " + targetMean + " : " + targetVariance);

        for (DatasetSimilarity sim : topKSimilar) {
            System.out.print(sim.index + ", ");
        }
        System.out.println();
        for (DatasetSimilarity sim : topKSimilar2) {
            System.out.print(sim.index + ", ");
        }
    }


    public static List<DatasetSimilarity> findTopKWithCandidates(
            Map<GridIndex, Double> sample,
            List<Map<GridIndex, Double>> PDFs,
            List<Integer> candidates,
            int k
    ) {
        // 使用优先队列维护 Top-K 结果
        PriorityQueue<DatasetSimilarity> topK = new PriorityQueue<>(
                Comparator.comparingDouble(ds -> -ds.jsd) // 按 JSD 从大到小排序
        );

        for (int candidateIndex : candidates) {
            Map<GridIndex, Double> candidatePDF = PDFs.get(candidateIndex);

            // 计算 JSD
            double jsd = Similarity_Calculator.calculateJSD(sample, candidatePDF);

            // 构造 DatasetSimilarity 对象
            DatasetSimilarity similarity = new DatasetSimilarity(candidateIndex, candidatePDF, jsd);

            // 动态维护前 K 个最优解
            if (topK.size() < k) {
                topK.add(similarity); // 未达到 K 个时直接加入
            } else if (jsd < topK.peek().jsd) {
                // 如果当前 JSD 小于堆中最大 JSD，则替换最差解
                topK.poll();
                topK.add(similarity);
            }
        }

        // 转换为列表并按 JSD 从小到大排序
        List<DatasetSimilarity> result = new ArrayList<>(topK);
        result.sort(Comparator.comparingDouble(ds -> ds.jsd));
        return result;
    }


    // 查找最相似的前k个数据集并保留索引信息
    public static List<DatasetSimilarity> findTopKSimilar(
            List<Map<GridIndex, Double>> datasets, // 稀疏概率分布
            Map<GridIndex, Double> sample, // 样本分布
            int k) {
        PriorityQueue<DatasetSimilarity> topK = new PriorityQueue<>(
                Comparator.comparingDouble(ds -> -ds.jsd) // 从大到小排序
        );

        for (int i = 0; i < datasets.size(); i++) {
            Map<GridIndex, Double> dataset = datasets.get(i);
            double jsd = Similarity_Calculator.calculateJSD(sample, dataset); // 使用稀疏概率分布计算JSD
            DatasetSimilarity ds = new DatasetSimilarity(i, dataset, jsd);

            if (topK.size() < k) {
                topK.add(ds);
            } else if (jsd < topK.peek().jsd) {
                topK.poll(); // 移除最差相似度的数据集
                topK.add(ds); // 加入新的更相似的数据集
            }
        }

        // 将结果从PriorityQueue转为列表并排序
        List<DatasetSimilarity> result = new ArrayList<>(topK);
        result.sort(Comparator.comparingDouble(ds -> ds.jsd));
        return result;
    }


    public static void PrintLI(List<int[][]> array) {
        for (int i = 0; i < array.size() / 150; i++) {
            System.out.println(i);
            for (int j = 0; j < array.get(i)[0].length; j++) {
                for (int k = 0; k < array.get(i)[0].length; k++) {
                    System.out.print(array.get(i)[k][j] + " ");
                }
                System.out.println();
            }
        }
    }

    public static void PrintLD(List<double[][]> array) {
        for (int i = 0; i < array.size() / 150; i++) {
            System.out.println(i);
            for (int j = 0; j < array.get(i)[0].length; j++) {
                for (int k = 0; k < array.get(i)[0].length; k++) {
                    System.out.print(array.get(i)[k][j] + " ");
                }
                System.out.println();
            }
        }
    }

    public static List<DatasetSimilarity_cs> findTopKSimilar_cs(List<double[][]> datasets, double[][] sample, int k) {
        List<DatasetSimilarity_cs> similarities = new ArrayList<>();

        // 计算所有数据集与样本的相似度
        for (int i = 0; i < datasets.size(); i++) {
            double[][] dataset = datasets.get(i);
            double cosineSimilarity = Similarity_Calculator.calculateCosineSimilarity(sample, dataset);
            DatasetSimilarity_cs ds = new DatasetSimilarity_cs(i, dataset, cosineSimilarity);
            similarities.add(ds);
        }

        // 按相似度从大到小排序
        similarities.sort((ds1, ds2) -> Double.compare(ds2.cosineSimilarity, ds1.cosineSimilarity));

        // 取前k个最相似的数据集
        return similarities.subList(0, Math.min(k, similarities.size()));
    }

    private static void PrintMenory() {
        Runtime runtime = Runtime.getRuntime();
        long totalMemory = runtime.totalMemory();
        long freeMemory = runtime.freeMemory();
        long usedMemory = totalMemory - freeMemory;
        double totalMemoryInMB = totalMemory / (1024 * 1024);
        double freeMemoryInMB = freeMemory / (1024 * 1024);
        double usedMemoryInMB = usedMemory / (1024 * 1024);
        System.out.println("Total memory: " + totalMemoryInMB + " MB");
        System.out.println("Used memory: " + usedMemoryInMB + " MB");
        System.out.println("Free memory: " + freeMemoryInMB + " MB");
    }

    private static void PrintI(int[][] ints) {
        for (int i = 0; i < ints.length; i++) {
            for (int j = 0; j < ints[i].length; j++) {
                System.out.print(ints[i][j] + " ");
            }
            System.out.println();
        }
    }

//    public static List<DatasetSimilarity> findTopKSimilar(List<double[][]> datasets, double[][] sample, int k) {
//        PriorityQueue<DatasetSimilarity> topK = new PriorityQueue<>(
//                Comparator.comparingDouble(ds -> -ds.jsd) // 从大到小排序
//        );
//
//        for (int i = 0; i < datasets.size(); i++) {
//            double[][] dataset = datasets.get(i);
//            double jsd = Similarity_Calculator.calculateJSD(sample, dataset);
//            DatasetSimilarity ds = new DatasetSimilarity(i, dataset, jsd);
//
//            if (topK.size() < k) {
//                topK.add(ds);
//            } else if (jsd < topK.peek().jsd) {
//                topK.poll(); // 移除最差相似度的数据集
//                topK.add(ds); // 加入新的更相似的数据集
//            }
//        }
//
//        // 将优先队列转为List并按相似度升序排序返回
//        List<DatasetSimilarity> result = new ArrayList<>(topK);
//        result.sort(Comparator.comparingDouble(ds -> ds.jsd)); // 按相似度升序
//        return result;
//    }

}
