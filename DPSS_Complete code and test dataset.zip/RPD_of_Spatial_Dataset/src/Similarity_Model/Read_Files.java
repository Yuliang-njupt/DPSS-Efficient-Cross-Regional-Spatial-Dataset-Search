package Similarity_Model;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Read_Files {
    private Read_Files() {}

    public static List<List<Double[]>> readCsvFilesFromDirectory(String directoryPath) {
        List<List<Double[]>> dataWarehouse = new ArrayList<>();

        File directory = new File(directoryPath);
        File[] files = directory.listFiles((dir, name) -> name.endsWith(".csv"));

        if (files != null) {
            for (File file : files) {
                try {
                    List<Double[]> dataset = readCsvFile(file.getAbsolutePath());
                    dataWarehouse.add(dataset);
                } catch (IOException e) {
                    System.err.println("Failed to read CSV file: " + file.getAbsolutePath());
                    e.printStackTrace();
                }
            }
        }

        return dataWarehouse;
    }

    public static List<Double[]> readCsvFile(String filePath) throws IOException {
        List<Double[]> dataset = new ArrayList<>();
        try (BufferedReader br = Files.newBufferedReader(Paths.get(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.isEmpty()) {
                    String[] values = line.split(",");
                    Double[] row = new Double[values.length];
                    for (int i = 0; i < values.length; i++) {
                        row[i] = Double.parseDouble(values[i].trim());
                    }
                    dataset.add(row);
                }
            }
        }
        return dataset;
    }

    // 读取当前批次的CSV文件
    public static List<List<Double[]>> readCsvFiles(File[] batchFiles) {
        List<List<Double[]>> dataWarehouse = new ArrayList<>();
        for (File file : batchFiles) {
            try {
                List<Double[]> dataset = readCsvFile(file.getAbsolutePath());
                dataWarehouse.add(dataset);
            } catch (IOException e) {
                System.err.println("Failed to read CSV file: " + file.getAbsolutePath());
                e.printStackTrace();
            }
        }
        return dataWarehouse;
    }

}
