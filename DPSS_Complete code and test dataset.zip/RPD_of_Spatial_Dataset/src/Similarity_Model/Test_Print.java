package Similarity_Model;

import java.util.List;
import java.util.Map;

import static Similarity_Model.Probability_density_distribution.gridCounts;
import static Similarity_Model.Read_Files.readCsvFilesFromDirectory;

public class Test_Print {
    private static final int resolution = 10;
    private static final int Top_K = 5;
    private static final double bandwidth = 8;

    public static void main(String[] args) {
        String directoryPath = "C:\\Users\\86151\\Desktop\\论文\\数据\\XYConverter public 0-1000";
        List<List<Double[]>> dataWarehouse = readCsvFilesFromDirectory(directoryPath);
        List<Map<GridIndex, Integer>> gridCounts = gridCounts(dataWarehouse, resolution);//PrintLI(gridCounts);
        System.out.println(gridCounts.size());

        int [] c = {10, 40, 658, 926, 322, 573, 337, 283, 661, 886};

        for (int i = 0; i < c.length; i ++ ){
            System.out.println(c[i]);
            PrintI(gridCounts.get(c[i]));
            System.out.println();
        }

    }
    private static void PrintI(Map<GridIndex, Integer> ints) {
        for (int i = 0; i < resolution; i++) {
            for (int j = 0; j < resolution; j++) {
                Integer value = ints.getOrDefault(new GridIndex(i, j), 0);
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }
}
