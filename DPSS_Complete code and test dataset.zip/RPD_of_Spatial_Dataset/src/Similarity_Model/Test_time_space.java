package Similarity_Model;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

import static Similarity_Model.Probability_density_distribution.*;
import static Similarity_Model.Read_Files.readCsvFilesFromDirectory;
import static Similarity_Model.Index.*;

public class Test_time_space {
    private static final int [] resolutions = {8, 16, 32, 64, 128};//网格划分参数，2的整次幂
    private static final int [] Top_Ks = {5, 10, 15, 20, 25};
    private static final double [] bandwidth_ratio = {0.04, 0.08, 0.12, 0.16, 0.20};//KDE的带宽
    private static final double [] ks = {0.1, 0.2, 0.3, 0.4, 0.5};//过滤参数
    private static final int iterations = 1;

    public static void main(String[] args) {
        int Top_K = 10;
        double k = 0.4;
        int resolution = 64;
        double bandwidth = resolution * 0.08;

        //for (int a = 0; a < resolutions.length; a++) {
            //resolution = resolutions[a];
            //bandwidth = resolution * 0.08;

            String directoryPath = "C:\\Users\\86151\\Desktop\\论文\\数据\\XYConverter public 0-1000";
            String pdfFilePath = directoryPath + "_PDFs_" + resolution + "_" + bandwidth + ".ser"; // 定义保存路径

            List<Map<GridIndex, Double>> PDFs;
            List<List<Double[]>> dataWarehouse = readCsvFilesFromDirectory(directoryPath);//所有文件都要读进来，后续要从中选取query

            File pdfFile = new File(pdfFilePath);
            if (pdfFile.exists()) {
                // 如果文件存在，加载 PDFs
                PDFs = DataPersistence.loadPDFsFromFile(pdfFilePath);
            } else {
                // 否则执行计算并保存 PDFs
                List<Map<GridIndex, Integer>> gridCounts = gridCounts(dataWarehouse, resolution);
                PDFs = calculateKDE(gridCounts, resolution, bandwidth, new GaussianKernel());// 计算所有数据集的kde很耗时间
                if (bandwidth == resolution * 0.08) {
                    DataPersistence.savePDFsToFile(PDFs, pdfFilePath);  // 保存 PDFs
                }
            }

            System.out.println("resolution: " + resolution);
            System.out.println("bandwidth: " + bandwidth);
            System.out.println("过滤参数k: " + k);
            System.out.println("Top_K: " + Top_K);

            Random random = new Random(42); // 随机数生成器

            //构建索引树
            Map<Integer, double[]> stats = calculateHilbertStats(PDFs, resolution);
            buildIndexTree(stats);

            // 初始化用于累加时间的变量
            long totalBaselineSearchTime = 0;
            long totalOptimizedLocalKDESearchTime = 0;
            long totalOptimizedPruningGlobalKDESearchTime = 0;
            long totalOptimizedLocalKDEPruningSearchTime = 0;
            long totalGridCountsTime = 0;
            long totalKDE3hTime = 0;
            long totalKDEGlobalTime = 0;
            long totalStats3hTime = 0;
            long totalStatsGlobalTime = 0;

            for (int i = 0; i < iterations; i++) {
                // 处理query
                int sampleIdx = random.nextInt(dataWarehouse.size());
                List<Double[]> sampleDataset = dataWarehouse.get(sampleIdx);
                List<List<Double[]>> singleSampleList = new ArrayList<>();
                singleSampleList.add(sampleDataset);

                // 记录 gridCounts 时间
                long gridCountsStartTime = System.currentTimeMillis();
                List<Map<GridIndex, Integer>> singleSampleGridCounts = gridCounts(singleSampleList, resolution);
                long gridCountsEndTime = System.currentTimeMillis();
                long gridCountsTime = gridCountsEndTime - gridCountsStartTime;
                totalGridCountsTime += gridCountsTime;

                // 记录全局范围的 KDE 计算时间
                long kdeGlobalStartTime = System.currentTimeMillis();
                List<Map<GridIndex, Double>> singleSamplePDFsGlobal = calculateKDEGlobal(singleSampleGridCounts, resolution, bandwidth, new GaussianKernel());
                long kdeGlobalEndTime = System.currentTimeMillis();
                long kdeGlobalTime = kdeGlobalEndTime - kdeGlobalStartTime;
                totalKDEGlobalTime += kdeGlobalTime;

                // 记录 3h 范围限制的 KDE 计算时间
                long kde3hStartTime = System.currentTimeMillis();
                List<Map<GridIndex, Double>> singleSamplePDFs3h = calculateKDE(singleSampleGridCounts, resolution, bandwidth, new GaussianKernel());
                long kde3hEndTime = System.currentTimeMillis();
                long kde3hTime = kde3hEndTime - kde3hStartTime;
                totalKDE3hTime += kde3hTime;

                Map<GridIndex, Double> sample3h = singleSamplePDFs3h.get(0);
                Map<GridIndex, Double> sampleGlobal = singleSamplePDFsGlobal.get(0);

                // 记录计算 sample3h 的 Hilbert 编码均值和方差的时间
                long stats3hStartTime = System.currentTimeMillis();
                List<Map<GridIndex, Double>> singleSamplePDFList3h = new ArrayList<>();
                singleSamplePDFList3h.add(sample3h);
                Map<Integer, double[]> singleSampleStats3h = calculateHilbertStats(singleSamplePDFList3h, resolution);
                double[] sampleStats3h = singleSampleStats3h.get(0);
                double targetMean3h = sampleStats3h[0];
                double targetVariance3h = sampleStats3h[1];
                long stats3hEndTime = System.currentTimeMillis();
                long stats3hTime = stats3hEndTime - stats3hStartTime;
                totalStats3hTime += stats3hTime;

                // 记录计算 sampleGlobal 的 Hilbert 编码均值和方差的时间
                long statsGlobalStartTime = System.currentTimeMillis();
                List<Map<GridIndex, Double>> singleSamplePDFListGlobal = new ArrayList<>();
                singleSamplePDFListGlobal.add(sampleGlobal);
                Map<Integer, double[]> singleSampleStatsGlobal = calculateHilbertStats(singleSamplePDFListGlobal, resolution);
                double[] sampleStatsGlobal = singleSampleStatsGlobal.get(0);
                double targetMeanGlobal = sampleStatsGlobal[0];
                double targetVarianceGlobal = sampleStatsGlobal[1];
                long statsGlobalEndTime = System.currentTimeMillis();
                long statsGlobalTime = statsGlobalEndTime - statsGlobalStartTime;
                totalStatsGlobalTime += statsGlobalTime;

                long searchStartTime;
                long searchEndTime;
                long searchTime;

                // baseline(全局KDE+暴力遍历）
                searchStartTime = System.currentTimeMillis();
                List<DatasetSimilarity> baselineResults = findTopKSimilar(PDFs, sampleGlobal, Top_K);
                searchEndTime = System.currentTimeMillis();
                searchTime = searchEndTime - searchStartTime;
                totalBaselineSearchTime += searchTime;

                // optimized - 局部KDE(暴力遍历)
                searchStartTime = System.currentTimeMillis();
                List<DatasetSimilarity> optimizedResults1 = findTopKSimilar(PDFs, sample3h, Top_K);
                searchEndTime = System.currentTimeMillis();
                searchTime = searchEndTime - searchStartTime;
                totalOptimizedLocalKDESearchTime += searchTime;

                // optimized - 剪枝(全局KDE)
                searchStartTime = System.currentTimeMillis();
                List<Integer> candidates1 = filterCandidates(targetMeanGlobal, targetVarianceGlobal, k);
                List<DatasetSimilarity> optimizedResults2 = findTopKWithCandidates(sampleGlobal, PDFs, candidates1, Top_K);
                System.out.println("optimizedResults2: " + optimizedResults2.size());
                searchEndTime = System.currentTimeMillis();
                searchTime = searchEndTime - searchStartTime;
                totalOptimizedPruningGlobalKDESearchTime += searchTime;

                // optimizied(局部KDE+剪枝)
                searchStartTime = System.currentTimeMillis();
                List<Integer> candidates2 = filterCandidates(targetMean3h, targetVariance3h, k);
                List<DatasetSimilarity> optimizedResults3 = findTopKWithCandidates(sample3h, PDFs, candidates2, Top_K);
                System.out.println("optimizedResults3: " + optimizedResults3.size());
                searchEndTime = System.currentTimeMillis();
                searchTime = searchEndTime - searchStartTime;
                totalOptimizedLocalKDEPruningSearchTime += searchTime;

            }

            // 计算平均值
            long averageBaselineSearchTime = totalBaselineSearchTime / iterations;
            long averageOptimizedLocalKDESearchTime = totalOptimizedLocalKDESearchTime / iterations;
            long averageOptimizedPruningGlobalKDESearchTime = totalOptimizedPruningGlobalKDESearchTime / iterations;
            long averageOptimizedLocalKDEPruningSearchTime = totalOptimizedLocalKDEPruningSearchTime / iterations;
            long averageGridCountsTime = totalGridCountsTime / iterations;
            long averageKDE3hTime = totalKDE3hTime / iterations;
            long averageKDEGlobalTime = totalKDEGlobalTime / iterations;
            long averageStats3hTime = totalStats3hTime / iterations;
            long averageStatsGlobalTime = totalStatsGlobalTime / iterations;

            // 输出平均值
            System.out.println("\n所有循环的平均值：");
            System.out.println("Baseline 搜索平均时间: " + averageBaselineSearchTime + " 毫秒");
            System.out.println("Optimized - 局部KDE 搜索平均时间: " + averageOptimizedLocalKDESearchTime + " 毫秒");
            System.out.println("Optimized - 剪枝(全局KDE) 搜索平均时间: " + averageOptimizedPruningGlobalKDESearchTime + " 毫秒");
            System.out.println("Optimized(局部KDE+剪枝) 搜索平均时间: " + averageOptimizedLocalKDEPruningSearchTime + " 毫秒");
            System.out.println("gridCounts 平均时间: " + averageGridCountsTime + " 毫秒");
            System.out.println("3h 范围限制的 KDE 计算平均时间: " + averageKDE3hTime + " 毫秒");
            System.out.println("全局范围的 KDE 计算平均时间: " + averageKDEGlobalTime + " 毫秒");
            System.out.println("计算 sample3h 的 Hilbert 编码均值和方差平均时间: " + averageStats3hTime + " 毫秒");
            System.out.println("计算 sampleGlobal 的 Hilbert 编码均值和方差平均时间: " + averageStatsGlobalTime + " 毫秒");

        //}
    }


    public static List<DatasetSimilarity> findTopKWithCandidates(
            Map<GridIndex, Double> sample,
            List<Map<GridIndex, Double>> PDFs,
            List<Integer> candidates,
            int k
    ) {
        // 使用优先队列维护 Top-K 结果
        PriorityQueue<DatasetSimilarity> topK = new PriorityQueue<>(
                Comparator.comparingDouble(ds -> -ds.jsd) // 按 JSD 从大到小排序
        );

        for (int candidateIndex : candidates) {
            Map<GridIndex, Double> candidatePDF = PDFs.get(candidateIndex);

            // 计算 JSD
            double jsd = Similarity_Calculator.calculateJSD(sample, candidatePDF);

            // 构造 DatasetSimilarity 对象
            DatasetSimilarity similarity = new DatasetSimilarity(candidateIndex, candidatePDF, jsd);

            // 动态维护前 K 个最优解
            if (topK.size() < k) {
                topK.add(similarity); // 未达到 K 个时直接加入
            } else if (jsd < topK.peek().jsd) {
                // 如果当前 JSD 小于堆中最大 JSD，则替换最差解
                topK.poll();
                topK.add(similarity);
            }
        }

        // 转换为列表并按 JSD 从小到大排序
        List<DatasetSimilarity> result = new ArrayList<>(topK);
        result.sort(Comparator.comparingDouble(ds -> ds.jsd));
        return result;
    }


    // 查找最相似的前k个数据集并保留索引信息
    public static List<DatasetSimilarity> findTopKSimilar(
            List<Map<GridIndex, Double>> datasets, // 概率分布
            Map<GridIndex, Double> sample, // 样本
            int k) {
        PriorityQueue<DatasetSimilarity> topK = new PriorityQueue<>(
                Comparator.comparingDouble(ds -> -ds.jsd) // 从大到小排序
        );

        for (int i = 0; i < datasets.size(); i++) {
            Map<GridIndex, Double> dataset = datasets.get(i);
            double jsd = Similarity_Calculator.calculateJSD(sample, dataset); // 使用稀疏概率分布计算JSD
            DatasetSimilarity ds = new DatasetSimilarity(i, dataset, jsd);

            if (topK.size() < k) {
                topK.add(ds);
            } else if (jsd < topK.peek().jsd) {
                topK.poll(); // 移除最差相似度的数据集
                topK.add(ds); // 加入新的更相似的数据集
            }
        }

        // 将结果从PriorityQueue转为列表并排序
        List<DatasetSimilarity> result = new ArrayList<>(topK);
        result.sort(Comparator.comparingDouble(ds -> ds.jsd));
        return result;
    }
}
