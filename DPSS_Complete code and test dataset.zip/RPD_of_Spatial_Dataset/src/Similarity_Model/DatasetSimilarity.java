package Similarity_Model;

//public class DatasetSimilarity {
//    public int index; // 数据集的索引号
//    public double[][] dataset; // 数据集
//    public double jsd; // 与样例数据集的JSD值
//
//    public DatasetSimilarity(int index, double[][] dataset, double jsd) {
//        this.index = index;
//        this.dataset = dataset;
//        this.jsd = jsd;
//    }
//}

import java.util.Map;

class DatasetSimilarity {
    int index; // 数据集索引
//    Map<GridIndex, Double> dataset; // 稀疏概率分布
    double jsd; // JSD 值

    public DatasetSimilarity(int index, Map<GridIndex, Double> dataset, double jsd) {
        this.index = index;
//        this.dataset = dataset;
        this.jsd = jsd;
    }
}
